/**
 * Matthew S Montoya
 * CS 3331
 * Dr. Yoonsik Cheon
 * Exam 1 Extra Credit
 * Last modified 28 March 2018
 */
import java.awt.Color;
import java.awt.Graphics;

public class Moon extends OrbitingBody{
	
	public Moon(int x, int y, Color color) {
		//super(x, y, color);
		// TODO Auto-generated constructor stub
	}

	String name;
	
	//Create Moon to animate
	protected OrbitingBody orbitingBody() {
		return null;
		//return new OrbitingBody(dim.width/2, dim.height/2, Color.GRAY);
	}
	


}
