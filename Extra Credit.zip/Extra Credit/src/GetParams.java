/**
 * Matthew S Montoya
 * CS 3331
 * Dr. Yoonsik Cheon
 * Exam 1 Extra Credit
 * Last modified 28 March 2018
 */

public interface GetParams {
	public static int getX(){
		return Sun.getX();
	}
	
	public static int getY() {
		return Sun.getY();
	}
}
